# Insight Atlas PDF Kit

Premium PDF generator for Insight Atlas book analysis documents.

**Version:** 1.1.0 (v13.3 Minimalist Premium Edition)

## What's New in v13.3

- **2026 Minimalism Refinements**: Tightened card padding for cleaner visual rhythm
- **Updated Footer Tagline**: Now italicized: *"Where the weight of understanding becomes the clarity to act."*
- **Enhanced Quote Boxes**: Attribution repositioned inside box, right-aligned
- **Smart At-a-Glance Wrapping**: Improved text flow for long values
- **SwiftUI Dashboard**: Complete macOS dashboard with hover states and animations

## Overview

This package provides everything needed to generate consistently styled, branded PDF documents for book analyses in your Xcode Mac app.

## Contents

```
InsightAtlasPDFKit/
├── Sources/
│   ├── insight_atlas_pdf.py      # Main PDF generator (Python)
│   ├── insight_atlas_cli.py      # CLI wrapper for shell access
│   ├── InsightAtlasStyle.swift   # SwiftUI color/typography constants
│   └── PDFGeneratorBridge.swift  # Swift-to-Python bridge
├── Assets/
│   └── Logo.png                  # Insight Atlas logo
├── Examples/
│   ├── sample_analysis.json      # Example analysis data structure
│   └── Extended_Mind_Premium.pdf # Reference output
└── README.md
```

## Requirements

### Python Dependencies

```bash
pip3 install reportlab
```

### macOS

- Python 3.8+
- Xcode 14+
- macOS 12+

## Integration Options

### Option 1: Python CLI (Recommended)

Call the Python script directly from your Swift app:

```swift
import Foundation

func generatePDF(bookTitle: String, bookAuthor: String, analysisJSON: URL, outputPath: URL) {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
    
    let scriptPath = Bundle.main.path(forResource: "insight_atlas_cli", ofType: "py")!
    let logoPath = Bundle.main.path(forResource: "Logo", ofType: "png")!
    
    process.arguments = [
        scriptPath,
        "--output", outputPath.path,
        "--title", bookTitle,
        "--author", bookAuthor,
        "--data", analysisJSON.path,
        "--logo", logoPath
    ]
    
    try? process.run()
    process.waitUntilExit()
}
```

### Option 2: PDFGeneratorBridge (Structured)

Use the included Swift bridge for type-safe generation:

```swift
let bridge = PDFGeneratorBridge()

let analysisData = PDFGeneratorBridge.createAnalysisData(
    atAGlance: [
        "Core Thesis": "Intelligence extends beyond the brain",
        "Framework": "4E Cognition",
        "Applications": "Workspace design, education"
    ],
    executiveSummary: "This analysis synthesizes...",
    centralThesis: "Intelligence is not confined to the brain...",
    sections: [
        ("Embodied Cognition", "Content here...", "◈", true)
    ],
    applications: [
        ("For Knowledge Workers", "Design physical workspaces..."),
        ("For Educators", "Incorporate movement...")
    ],
    limitations: "While compelling...",
    keyTakeaways: "The Extended Mind offers..."
)

bridge.generatePDF(
    outputPath: outputURL.path,
    bookTitle: "The Extended Mind",
    bookAuthor: "Annie Murphy Paul",
    analysisData: analysisData
) { result in
    switch result {
    case .success(let url):
        print("PDF saved to: \(url)")
    case .failure(let error):
        print("Error: \(error)")
    }
}
```

### Option 3: Direct Python Import

For more control, import the Python module directly:

```python
from insight_atlas_pdf import InsightAtlasPDF, InsightAtlasColors

pdf = InsightAtlasPDF()
pdf.generate(
    output_path="analysis.pdf",
    book_title="Book Title",
    book_author="Author Name",
    analysis_data=your_data_dict,
    logo_path="Assets/Logo.png"
)
```

## Analysis Data Structure

The analysis data is a dictionary with the following structure:

```json
{
    "at_a_glance": {
        "Core Thesis": "One-line summary",
        "Framework": "Theoretical framework",
        "Applications": "Key application areas"
    },
    "toc": [
        {"title": "Executive Summary", "page": "3", "is_sub": false},
        {"title": "Central Thesis", "page": "3", "is_sub": false},
        {"title": "Embodied Cognition", "page": "3", "is_sub": true}
    ],
    "pages": [
        [
            {"type": "h2", "text": "Executive Summary", "icon": "☉", "color": "#CBA135"},
            {"type": "paragraph", "text": "Content here..."},
            {"type": "divider"},
            {"type": "h3", "text": "Central Thesis", "color": "#582534"},
            {"type": "card", "text": "Thesis content...", "color": "#CBA135"},
            {"type": "bullet_list", "items": [
                {"label": "For Workers", "text": "Application details..."}
            ]},
            {"type": "quote", "lines": ["Line 1", "Line 2"], "attribution": "Insight Atlas"}
        ]
    ]
}
```

### Section Types

| Type | Description | Required Fields |
|------|-------------|-----------------|
| `h2` | Major section header with badge | `text`, `icon`, `color` |
| `h3` | Subsection header (uppercase) | `text`, `color` |
| `paragraph` | Body text | `text` |
| `card` | Highlighted card with accent | `text`, `color` |
| `divider` | Three-dot separator | (none) |
| `bullet_list` | Labeled bullet points | `items` |
| `quote` | Pull quote with attribution | `lines`, `attribution` |

### Section Icons

| Icon | Usage |
|------|-------|
| `☉` | Executive Summary |
| `◈` | Theoretical Framework |
| `✦` | Practical Applications |
| `◇` | Limitations |
| `★` | Key Takeaways |
| `◆` | Generic |

### Colors

| Hex | Name | Usage |
|-----|------|-------|
| `#CBA135` | Gold | Primary accent, most badges |
| `#582534` | Burgundy | H3 headers, secondary badges |
| `#E76F51` | Coral | Limitations/warnings |
| `#1C1C1E` | Heading | Main heading text |
| `#2C2C2E` | Body | Body text |
| `#4A5568` | Muted | Footer, secondary text |
| `#FAFAFA` | Background | Page background |
| `#F9F8F5` | Card | Card background (warm cream) |

## Xcode Setup

1. **Add Python script to bundle:**
   - Drag `Sources/insight_atlas_pdf.py` and `Sources/insight_atlas_cli.py` to your Xcode project
   - Ensure "Copy items if needed" is checked
   - Add to target's "Copy Bundle Resources"

2. **Add Logo:**
   - Drag `Assets/Logo.png` to your asset catalog or Resources folder

3. **Add Swift files:**
   - Drag `Sources/InsightAtlasStyle.swift` and `Sources/PDFGeneratorBridge.swift` to your project
   - Add to your app target

4. **Sandbox considerations:**
   - If sandboxed, you may need to bundle Python or use a helper tool
   - Consider using `NSUserUnixTask` for sandboxed execution

## Customization

### Changing the Tagline

Edit in `insight_atlas_pdf.py`:

```python
# In draw_footer():
tagline = "Your Custom Tagline Here"

# In build_cover_page():
c.drawCentredString(..., "Your Top Line")
c.drawCentredString(..., "Your Bottom Line")
```

### Adjusting Colors

Modify the `InsightAtlasColors` class:

```python
class InsightAtlasColors:
    GOLD = HexColor('#YOUR_COLOR')
    # ...
```

### Custom Fonts

Place `.ttf` files in `Assets/Fonts/` and update the font registration in `InsightAtlasTypography._register_fonts()`.

## Command Line Usage

```bash
# Basic usage
python3 insight_atlas_cli.py \
    --output analysis.pdf \
    --title "The Extended Mind" \
    --author "Annie Murphy Paul" \
    --data analysis.json \
    --logo Logo.png

# Quick generation with direct content
python3 insight_atlas_cli.py \
    --output quick.pdf \
    --title "Book Title" \
    --author "Author" \
    --summary "Executive summary here..." \
    --thesis "Central thesis here..." \
    --takeaways "Key takeaways here..."
```

## Troubleshooting

### "reportlab not found"
```bash
pip3 install reportlab
```

### Fonts not rendering correctly
The generator falls back to Helvetica if DejaVu fonts aren't found. Install them:
```bash
# macOS (with Homebrew)
brew install font-dejavu

# Or download from: https://dejavu-fonts.github.io/
```

### PDF not generating
Check Python output for errors:
```swift
let pipe = Pipe()
process.standardError = pipe
// ... run process ...
let errorData = pipe.fileHandleForReading.readDataToEndOfFile()
print(String(data: errorData, encoding: .utf8) ?? "")
```

## Version History

- **v1.0.0** (based on v13.2): Initial release
  - Warm cream card backgrounds
  - Italicized footer tagline
  - Updated pull quote
  - Proper text wrapping on cover

## License

Proprietary - Insight Atlas

## Support

For issues or feature requests, contact the Insight Atlas development team.
