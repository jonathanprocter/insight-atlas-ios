//
//  InsightAtlasStyle.swift
//  Insight Atlas
//
//  Brand style constants for consistent UI across the app.
//  These values match the PDF generator for visual consistency.
//

import SwiftUI

// MARK: - Color Palette

struct InsightAtlasColors {
    
    // MARK: Primary Gold
    static let gold = Color(hex: "#CBA135")
    static let goldLight = Color(hex: "#DCBE5E")
    static let goldDark = Color(hex: "#A88A2D")
    
    // MARK: Text Colors
    static let heading = Color(hex: "#1C1C1E")
    static let body = Color(hex: "#2C2C2E")
    static let muted = Color(hex: "#4A5568")
    
    // MARK: Backgrounds
    static let background = Color(hex: "#FAFAFA")
    static let backgroundAlt = Color(hex: "#F5F5F5")
    static let card = Color(hex: "#F9F8F5")  // Warm cream
    
    // MARK: Borders & Rules
    static let rule = Color(hex: "#D1CDC7")
    static let ruleLight = Color(hex: "#E5E2DD")
    
    // MARK: Accent Colors
    static let burgundy = Color(hex: "#582534")
    static let burgundyLight = Color(hex: "#7A3A4D")
    static let coral = Color(hex: "#E76F51")
    static let coralLight = Color(hex: "#F09A85")
}

// MARK: - Typography

struct InsightAtlasTypography {
    
    // Headings - Sans Serif
    static let h1 = Font.system(size: 28, weight: .bold, design: .default)
    static let h2 = Font.system(size: 15, weight: .bold, design: .default)
    static let h3 = Font.system(size: 10, weight: .bold, design: .default)
    
    // Body - Serif
    static let body = Font.system(size: 10.5, weight: .regular, design: .serif)
    static let bodyBold = Font.system(size: 10.5, weight: .bold, design: .serif)
    static let bodyItalic = Font.system(size: 10.5, weight: .regular, design: .serif).italic()
    
    // UI Elements
    static let caption = Font.system(size: 8, weight: .regular, design: .default)
    static let button = Font.system(size: 11, weight: .semibold, design: .default)
}

// MARK: - Spacing

struct InsightAtlasSpacing {
    static let xs: CGFloat = 6
    static let sm: CGFloat = 10
    static let md: CGFloat = 16
    static let lg: CGFloat = 22
    static let xl: CGFloat = 32
}

// MARK: - Brand Assets

struct InsightAtlasBrand {
    static let tagline = "Where Understanding Illuminates the World"
    static let taglineShort = "Clarity is Strength"
    static let pullQuote = "Where the weight of understanding becomes the clarity to act."
    static let footerTagline = "Where the weight of understanding becomes the clarity to act."  // v13.3
}

// MARK: - Section Icons

struct InsightAtlasSectionIcons {
    static let executiveSummary = "☉"
    static let theoreticalFramework = "◈"
    static let practicalApplications = "✦"
    static let limitations = "◇"
    static let keyTakeaways = "★"
    static let generic = "◆"
}

// MARK: - Color Extension

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

// MARK: - NSColor Extension (for AppKit)

#if canImport(AppKit)
import AppKit

extension NSColor {
    static let iaGold = NSColor(hex: "#CBA135")
    static let iaGoldLight = NSColor(hex: "#DCBE5E")
    static let iaGoldDark = NSColor(hex: "#A88A2D")
    static let iaHeading = NSColor(hex: "#1C1C1E")
    static let iaBody = NSColor(hex: "#2C2C2E")
    static let iaMuted = NSColor(hex: "#4A5568")
    static let iaBackground = NSColor(hex: "#FAFAFA")
    static let iaCard = NSColor(hex: "#F9F8F5")
    static let iaRule = NSColor(hex: "#D1CDC7")
    static let iaBurgundy = NSColor(hex: "#582534")
    static let iaCoral = NSColor(hex: "#E76F51")
    
    convenience init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let r, g, b, a: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            red: CGFloat(r) / 255,
            green: CGFloat(g) / 255,
            blue: CGFloat(b) / 255,
            alpha: CGFloat(a) / 255
        )
    }
}
#endif
