#!/usr/bin/env python3
"""
Insight Atlas Premium PDF Generator
Template System for Book Analysis Documents

Version: 1.1.0 (v13.3 Minimalist Premium Edition)
Author: Insight Atlas

2026 Minimalism Refinements:
- Tightened card padding for cleaner visual rhythm
- Italicized footer tagline for subtle elegance
- Enhanced At-a-Glance smart wrapping
- Refined quote box attribution placement

This module generates branded PDF analysis documents for any book.
It provides a consistent visual identity with the Insight Atlas brand.

Usage:
    from insight_atlas_pdf import InsightAtlasPDF
    
    pdf = InsightAtlasPDF()
    pdf.generate(
        output_path="output.pdf",
        book_title="The Extended Mind",
        book_author="Annie Murphy Paul",
        analysis_data=analysis_dict,
        logo_path="Assets/Logo.png"  # Optional
    )
"""

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib.colors import HexColor
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
import os
from datetime import datetime
from typing import Optional, Dict, List, Any

# ═══════════════════════════════════════════════════════════════
# BRAND CONSTANTS
# ═══════════════════════════════════════════════════════════════

class InsightAtlasColors:
    """Official Insight Atlas color palette."""
    
    # Primary gold
    GOLD = HexColor('#CBA135')
    GOLD_LIGHT = HexColor('#DCBE5E')
    GOLD_DARK = HexColor('#A88A2D')
    
    # Near black for headings
    HEADING = HexColor('#1C1C1E')
    
    # Body text
    BODY = HexColor('#2C2C2E')
    
    # Cool gray for muted/secondary
    MUTED = HexColor('#4A5568')
    
    # Backgrounds
    BG = HexColor('#FAFAFA')
    BG_ALT = HexColor('#F5F5F5')
    CARD = HexColor('#F9F8F5')  # Warm cream
    
    # Rules/borders
    RULE = HexColor('#D1CDC7')
    RULE_LIGHT = HexColor('#E5E2DD')
    
    # Deep burgundy accent
    BURGUNDY = HexColor('#582534')
    BURGUNDY_LIGHT = HexColor('#7A3A4D')
    
    # Coral/terracotta highlight
    CORAL = HexColor('#E76F51')
    CORAL_LIGHT = HexColor('#F09A85')


class InsightAtlasTypography:
    """Typography settings with fallbacks."""
    
    def __init__(self):
        self.fonts_available = self._register_fonts()
        
        if self.fonts_available:
            self.HEADING = 'DejaVuSans-Bold'
            self.HEADING_REGULAR = 'DejaVuSans'
            self.BODY = 'DejaVuSerif'
            self.BODY_ITALIC = 'DejaVuSerif-Italic'
            self.BODY_BOLD = 'DejaVuSerif-Bold'
        else:
            self.HEADING = 'Helvetica-Bold'
            self.HEADING_REGULAR = 'Helvetica'
            self.BODY = 'Helvetica'
            self.BODY_ITALIC = 'Helvetica-Oblique'
            self.BODY_BOLD = 'Helvetica-Bold'
    
    def _register_fonts(self) -> bool:
        """Attempt to register premium fonts."""
        font_paths = [
            # Linux paths
            '/usr/share/fonts/truetype/dejavu/',
            # macOS paths
            '/Library/Fonts/',
            '~/Library/Fonts/',
            # Windows paths
            'C:/Windows/Fonts/',
            # Bundled fonts (relative to this file)
            os.path.join(os.path.dirname(__file__), 'Assets/Fonts/'),
        ]
        
        for base_path in font_paths:
            base_path = os.path.expanduser(base_path)
            try:
                pdfmetrics.registerFont(TTFont('DejaVuSerif', 
                    os.path.join(base_path, 'DejaVuSerif.ttf')))
                pdfmetrics.registerFont(TTFont('DejaVuSerif-Bold', 
                    os.path.join(base_path, 'DejaVuSerif-Bold.ttf')))
                pdfmetrics.registerFont(TTFont('DejaVuSerif-Italic', 
                    os.path.join(base_path, 'DejaVuSerif-Italic.ttf')))
                pdfmetrics.registerFont(TTFont('DejaVuSans', 
                    os.path.join(base_path, 'DejaVuSans.ttf')))
                pdfmetrics.registerFont(TTFont('DejaVuSans-Bold', 
                    os.path.join(base_path, 'DejaVuSans-Bold.ttf')))
                return True
            except:
                continue
        
        return False


class InsightAtlasLayout:
    """Layout constants for consistent spacing."""
    
    PAGE_WIDTH, PAGE_HEIGHT = letter
    MARGIN_LEFT = 1.4 * inch
    MARGIN_RIGHT = 1.4 * inch
    MARGIN_TOP = 1.0 * inch
    MARGIN_BOTTOM = 1.0 * inch
    TEXT_WIDTH = PAGE_WIDTH - MARGIN_LEFT - MARGIN_RIGHT
    
    CONTENT_TOP = PAGE_HEIGHT - MARGIN_TOP - 30
    CONTENT_BOTTOM = MARGIN_BOTTOM + 40
    
    # Typography scale
    H1_SIZE = 28
    H2_SIZE = 15
    H3_SIZE = 10
    BODY_SIZE = 10.5
    BODY_LEADING = 15
    
    # Spacing
    SPACE_XS = 6
    SPACE_SM = 10
    SPACE_MD = 16
    SPACE_LG = 22
    SPACE_XL = 32


# ═══════════════════════════════════════════════════════════════
# MAIN PDF GENERATOR CLASS
# ═══════════════════════════════════════════════════════════════

class InsightAtlasPDF:
    """
    Premium PDF generator for Insight Atlas book analyses.
    
    This class provides methods to create professionally styled
    PDF documents with consistent branding.
    """
    
    def __init__(self):
        self.colors = InsightAtlasColors()
        self.typography = InsightAtlasTypography()
        self.layout = InsightAtlasLayout()
        self.canvas = None
        self.current_page = 0
    
    # ─────────────────────────────────────────────────────────────
    # TEXT UTILITIES
    # ─────────────────────────────────────────────────────────────
    
    def wrap_text(self, text: str, font: str, size: float, max_width: float) -> List[str]:
        """Wrap text to fit within max_width."""
        words = text.split()
        lines = []
        current_line = []
        
        for word in words:
            test_line = ' '.join(current_line + [word])
            if self.canvas.stringWidth(test_line, font, size) <= max_width:
                current_line.append(word)
            else:
                if current_line:
                    lines.append(' '.join(current_line))
                current_line = [word]
        
        if current_line:
            lines.append(' '.join(current_line))
        
        return lines
    
    def calc_text_height(self, text: str, font: str, size: float, 
                         max_width: float, leading: float) -> float:
        """Calculate height needed for wrapped text."""
        lines = self.wrap_text(text, font, size, max_width)
        return len(lines) * leading
    
    def draw_paragraph(self, text: str, x: float, y: float, 
                       font: str, size: float, max_width: float, 
                       leading: float, color=None) -> float:
        """Draw a paragraph with word wrapping. Returns new Y position."""
        if color:
            self.canvas.setFillColor(color)
        self.canvas.setFont(font, size)
        
        lines = self.wrap_text(text, font, size, max_width)
        current_y = y
        
        for line in lines:
            self.canvas.drawString(x, current_y, line)
            current_y -= leading
        
        return current_y
    
    # ─────────────────────────────────────────────────────────────
    # DESIGN ELEMENTS
    # ─────────────────────────────────────────────────────────────
    
    def draw_circular_badge(self, x: float, y: float, icon_char: str, 
                            color, size: float = 22):
        """Draw a circular badge with icon."""
        self.canvas.setFillColor(color)
        self.canvas.circle(x, y, size/2, fill=1, stroke=0)
        
        self.canvas.setFillColor(self.colors.BG)
        self.canvas.setFont(self.typography.HEADING, size * 0.5)
        char_width = self.canvas.stringWidth(icon_char, self.typography.HEADING, size * 0.5)
        self.canvas.drawString(x - char_width/2, y - size * 0.18, icon_char)
    
    def draw_h2_with_badge(self, text: str, x: float, y: float, 
                           badge_icon: str = "◆", badge_color=None) -> float:
        """Section header with circular badge."""
        if badge_color is None:
            badge_color = self.colors.GOLD
        
        badge_x = x + 11
        badge_y = y + 2
        self.draw_circular_badge(badge_x, badge_y, badge_icon, badge_color, size=22)
        
        text_x = x + 32
        self.canvas.setFillColor(self.colors.HEADING)
        self.canvas.setFont(self.typography.HEADING, self.layout.H2_SIZE)
        self.canvas.drawString(text_x, y, text)
        
        return y - 26
    
    def draw_h3_header(self, text: str, x: float, y: float, color=None) -> float:
        """Subsection header in uppercase."""
        if color is None:
            color = self.colors.BURGUNDY
        self.canvas.setFillColor(color)
        self.canvas.setFont(self.typography.HEADING, self.layout.H3_SIZE)
        self.canvas.drawString(x, y, text.upper())
        return y - 14
    
    def draw_section_divider(self, y: float) -> float:
        """Subtle divider with centered gold dots."""
        center_x = self.layout.PAGE_WIDTH / 2
        self.canvas.setFillColor(self.colors.GOLD)
        
        self.canvas.circle(center_x - 12, y, 2, fill=1, stroke=0)
        self.canvas.circle(center_x, y, 2.5, fill=1, stroke=0)
        self.canvas.circle(center_x + 12, y, 2, fill=1, stroke=0)
        
        return y - self.layout.SPACE_MD
    
    def draw_card(self, x: float, y: float, width: float, height: float, 
                  accent_color=None):
        """Draw a card with warm cream background and accent bar."""
        if accent_color is None:
            accent_color = self.colors.GOLD
        
        self.canvas.setFillColor(self.colors.CARD)
        self.canvas.setStrokeColor(self.colors.RULE)
        self.canvas.setLineWidth(0.5)
        self.canvas.roundRect(x, y - height, width, height, 4, fill=1, stroke=1)
        
        # Left accent bar
        self.canvas.setFillColor(accent_color)
        self.canvas.roundRect(x, y - height, 4, height, 2, fill=1, stroke=0)
    
    def draw_decorative_frame(self):
        """Decorative corner elements in gold."""
        corner_size = 30
        offset = 0.8 * inch
        
        self.canvas.setStrokeColor(self.colors.GOLD)
        self.canvas.setLineWidth(1.5)
        
        pw, ph = self.layout.PAGE_WIDTH, self.layout.PAGE_HEIGHT
        
        # Top-left
        self.canvas.line(offset, ph - offset, offset + corner_size, ph - offset)
        self.canvas.line(offset, ph - offset, offset, ph - offset - corner_size)
        
        # Top-right
        self.canvas.line(pw - offset, ph - offset, pw - offset - corner_size, ph - offset)
        self.canvas.line(pw - offset, ph - offset, pw - offset, ph - offset - corner_size)
        
        # Bottom-left
        self.canvas.line(offset, offset, offset + corner_size, offset)
        self.canvas.line(offset, offset, offset, offset + corner_size)
        
        # Bottom-right
        self.canvas.line(pw - offset, offset, pw - offset - corner_size, offset)
        self.canvas.line(pw - offset, offset, pw - offset, offset + corner_size)
    
    # ─────────────────────────────────────────────────────────────
    # HEADER & FOOTER
    # ─────────────────────────────────────────────────────────────
    
    def draw_header(self):
        """Running header with gold accent."""
        y = self.layout.PAGE_HEIGHT - self.layout.MARGIN_TOP + 15
        
        self.canvas.setFillColor(self.colors.GOLD)
        self.canvas.circle(self.layout.MARGIN_LEFT + 4, y + 2, 3, fill=1, stroke=0)
        
        self.canvas.setFillColor(self.colors.MUTED)
        self.canvas.setFont(self.typography.HEADING_REGULAR, 8)
        self.canvas.drawString(self.layout.MARGIN_LEFT + 14, y, "INSIGHT ATLAS ANALYSIS")
        
        self.canvas.setStrokeColor(self.colors.GOLD_LIGHT)
        self.canvas.setLineWidth(0.75)
        self.canvas.line(self.layout.MARGIN_LEFT, y - 8, 
                        self.layout.PAGE_WIDTH - self.layout.MARGIN_RIGHT, y - 8)
    
    def draw_footer(self, page_num: int):
        """Brand footer with italicized tagline."""
        footer_y = self.layout.MARGIN_BOTTOM - 15
        
        self.canvas.setStrokeColor(self.colors.RULE)
        self.canvas.setLineWidth(0.5)
        self.canvas.line(self.layout.MARGIN_LEFT, footer_y + 18, 
                        self.layout.PAGE_WIDTH - self.layout.MARGIN_RIGHT, footer_y + 18)
        
        # Brand name
        self.canvas.setFillColor(self.colors.GOLD)
        self.canvas.setFont(self.typography.HEADING, 8)
        self.canvas.drawString(self.layout.MARGIN_LEFT, footer_y, "INSIGHT ATLAS")
        
        # Tagline (italicized) - v13.3: Updated to clarity tagline
        self.canvas.setFillColor(self.colors.MUTED)
        self.canvas.setFont(self.typography.BODY_ITALIC, 7)
        tagline = "Where the weight of understanding becomes the clarity to act."
        tagline_width = self.canvas.stringWidth(tagline, self.typography.BODY_ITALIC, 7)
        self.canvas.drawString((self.layout.PAGE_WIDTH - tagline_width) / 2, footer_y, tagline)
        
        # Page number
        self.canvas.setFillColor(self.colors.MUTED)
        self.canvas.setFont(self.typography.HEADING_REGULAR, 8)
        self.canvas.drawRightString(self.layout.PAGE_WIDTH - self.layout.MARGIN_RIGHT, 
                                   footer_y, f"Page {page_num}")
    
    # ─────────────────────────────────────────────────────────────
    # PAGE BUILDERS
    # ─────────────────────────────────────────────────────────────
    
    def build_cover_page(self, book_title: str, book_author: str, 
                         at_a_glance: Dict[str, str], logo_path: Optional[str] = None):
        """Build the cover page."""
        self.canvas.setPageSize(letter)
        
        # Background
        self.canvas.setFillColor(self.colors.BG)
        self.canvas.rect(0, 0, self.layout.PAGE_WIDTH, self.layout.PAGE_HEIGHT, fill=1, stroke=0)
        
        # Decorative frame
        self.draw_decorative_frame()
        
        # Top gold accent bar
        self.canvas.setStrokeColor(self.colors.GOLD)
        self.canvas.setLineWidth(3)
        self.canvas.line(self.layout.PAGE_WIDTH/2 - 45, self.layout.PAGE_HEIGHT - 1.5*inch,
                        self.layout.PAGE_WIDTH/2 + 45, self.layout.PAGE_HEIGHT - 1.5*inch)
        
        # Title
        title_y = self.layout.PAGE_HEIGHT - 2.3 * inch
        self.canvas.setFillColor(self.colors.HEADING)
        self.canvas.setFont(self.typography.HEADING, 36)
        self.canvas.drawCentredString(self.layout.PAGE_WIDTH / 2, title_y, book_title)
        
        # Author
        self.canvas.setFillColor(self.colors.MUTED)
        self.canvas.setFont(self.typography.BODY_ITALIC, 15)
        self.canvas.drawCentredString(self.layout.PAGE_WIDTH / 2, title_y - 40, f"by {book_author}")
        
        # Decorative divider
        div_y = title_y - 85
        self.canvas.setStrokeColor(self.colors.GOLD)
        self.canvas.setLineWidth(1.5)
        self.canvas.line(self.layout.PAGE_WIDTH/2 - 60, div_y, self.layout.PAGE_WIDTH/2 - 10, div_y)
        self.canvas.line(self.layout.PAGE_WIDTH/2 + 10, div_y, self.layout.PAGE_WIDTH/2 + 60, div_y)
        
        self.canvas.setFillColor(self.colors.BURGUNDY)
        self.canvas.circle(self.layout.PAGE_WIDTH/2, div_y, 4, fill=1, stroke=0)
        
        # Date
        self.canvas.setFillColor(self.colors.BURGUNDY)
        self.canvas.setFont(self.typography.HEADING_REGULAR, 11)
        date_str = datetime.now().strftime("%B %Y")
        self.canvas.drawCentredString(self.layout.PAGE_WIDTH / 2, div_y - 28, date_str)
        
        # At a Glance card
        card_y = div_y - 70
        card_height = 115
        card_width = 5.0 * inch
        card_x = (self.layout.PAGE_WIDTH - card_width) / 2
        
        self.draw_card(card_x, card_y, card_width, card_height, accent_color=self.colors.GOLD)
        
        self.canvas.setFillColor(self.colors.BURGUNDY)
        self.canvas.setFont(self.typography.HEADING, 9)
        self.canvas.drawString(card_x + 18, card_y - 20, "AT A GLANCE")
        
        content_start_x = card_x + 18
        content_width = card_width - 36
        
        item_y = card_y - 42
        for label, value in at_a_glance.items():
            self.canvas.setFillColor(self.colors.GOLD_DARK)
            self.canvas.setFont(self.typography.HEADING, 8)
            self.canvas.drawString(content_start_x, item_y, f"{label}:")
            
            label_width = self.canvas.stringWidth(f"{label}: ", self.typography.HEADING, 8)
            value_x = content_start_x + label_width
            available_width = content_width - label_width
            
            self.canvas.setFillColor(self.colors.BODY)
            self.canvas.setFont(self.typography.BODY, 9)
            
            value_width = self.canvas.stringWidth(value, self.typography.BODY, 9)
            if value_width <= available_width:
                self.canvas.drawString(value_x, item_y, value)
                item_y -= 20
            else:
                lines = self.wrap_text(value, self.typography.BODY, 9, content_width - 10)
                for i, line in enumerate(lines):
                    if i == 0:
                        self.canvas.drawString(value_x, item_y, line)
                    else:
                        self.canvas.drawString(content_start_x + 10, item_y, line)
                    item_y -= 14
                item_y -= 6
        
        # Tagline
        tagline_y = 2.8 * inch
        self.canvas.setFillColor(self.colors.HEADING)
        self.canvas.setFont(self.typography.HEADING, 11)
        self.canvas.drawCentredString(self.layout.PAGE_WIDTH / 2, tagline_y + 16, "Where Understanding")
        self.canvas.setFillColor(self.colors.GOLD)
        self.canvas.setFont(self.typography.HEADING, 11)
        self.canvas.drawCentredString(self.layout.PAGE_WIDTH / 2, tagline_y, "Illuminates the World")
        
        # Logo
        if logo_path and os.path.exists(logo_path):
            try:
                logo_size = 1.2 * inch
                logo_x = (self.layout.PAGE_WIDTH - logo_size) / 2
                logo_y = tagline_y - logo_size - 0.35 * inch
                img = ImageReader(logo_path)
                self.canvas.drawImage(img, logo_x, logo_y,
                                     width=logo_size, height=logo_size,
                                     preserveAspectRatio=True, mask='auto')
            except Exception as e:
                print(f"Logo error: {e}")
        
        self.canvas.showPage()
        self.current_page += 1
    
    def build_toc_page(self, sections: List[Dict[str, Any]]):
        """Build table of contents page."""
        self.canvas.setPageSize(letter)
        
        self.canvas.setFillColor(self.colors.BG)
        self.canvas.rect(0, 0, self.layout.PAGE_WIDTH, self.layout.PAGE_HEIGHT, fill=1, stroke=0)
        
        self.draw_header()
        y = self.layout.CONTENT_TOP
        
        # Title
        self.canvas.setFillColor(self.colors.HEADING)
        self.canvas.setFont(self.typography.HEADING, 20)
        self.canvas.drawString(self.layout.MARGIN_LEFT, y, "Contents")
        
        # Gold underline
        self.canvas.setStrokeColor(self.colors.GOLD)
        self.canvas.setLineWidth(2.5)
        self.canvas.line(self.layout.MARGIN_LEFT, y - 8, self.layout.MARGIN_LEFT + 90, y - 8)
        
        y -= 50
        
        for item in sections:
            title = item.get('title', '')
            page = item.get('page', '')
            is_sub = item.get('is_sub', False)
            
            if is_sub:
                self.canvas.setFillColor(self.colors.MUTED)
                self.canvas.setFont(self.typography.BODY, 10)
                x_offset = 20
                font = self.typography.BODY
                size = 10
            else:
                self.canvas.setFillColor(self.colors.BODY)
                self.canvas.setFont(self.typography.HEADING_REGULAR, 11)
                x_offset = 0
                font = self.typography.HEADING_REGULAR
                size = 11
            
            self.canvas.drawString(self.layout.MARGIN_LEFT + x_offset, y, title)
            
            # Dotted leader
            title_width = self.canvas.stringWidth(title, font, size)
            leader_start = self.layout.MARGIN_LEFT + x_offset + title_width + 8
            leader_end = self.layout.PAGE_WIDTH - self.layout.MARGIN_RIGHT - 20
            
            self.canvas.setFillColor(self.colors.RULE)
            dot_x = leader_start
            while dot_x < leader_end:
                self.canvas.circle(dot_x, y + 3, 0.5, fill=1, stroke=0)
                dot_x += 6
            
            # Page number
            self.canvas.setFillColor(self.colors.GOLD)
            self.canvas.setFont(self.typography.HEADING_REGULAR, 10)
            self.canvas.drawRightString(self.layout.PAGE_WIDTH - self.layout.MARGIN_RIGHT, y, str(page))
            
            y -= 22
        
        self.draw_footer(self.current_page + 1)
        self.canvas.showPage()
        self.current_page += 1
    
    def build_content_page(self, sections: List[Dict[str, Any]], page_num: int):
        """Build a content page with sections."""
        self.canvas.setPageSize(letter)
        
        self.canvas.setFillColor(self.colors.BG)
        self.canvas.rect(0, 0, self.layout.PAGE_WIDTH, self.layout.PAGE_HEIGHT, fill=1, stroke=0)
        
        self.draw_header()
        y = self.layout.CONTENT_TOP
        
        for section in sections:
            section_type = section.get('type', 'paragraph')
            
            if section_type == 'h2':
                y = self.draw_h2_with_badge(
                    section.get('text', ''),
                    self.layout.MARGIN_LEFT, y,
                    section.get('icon', '◆'),
                    section.get('color', self.colors.GOLD)
                )
            
            elif section_type == 'h3':
                y = self.draw_h3_header(
                    section.get('text', ''),
                    self.layout.MARGIN_LEFT, y,
                    section.get('color', self.colors.BURGUNDY)
                )
                y -= self.layout.SPACE_XS
            
            elif section_type == 'paragraph':
                y = self.draw_paragraph(
                    section.get('text', ''),
                    self.layout.MARGIN_LEFT, y,
                    self.typography.BODY, self.layout.BODY_SIZE,
                    self.layout.TEXT_WIDTH, self.layout.BODY_LEADING,
                    color=self.colors.BODY
                )
                y -= self.layout.SPACE_MD
            
            elif section_type == 'card':
                text = section.get('text', '')
                box_text_width = self.layout.TEXT_WIDTH - 24  # v13.3: Tighter padding
                text_height = self.calc_text_height(
                    text, self.typography.BODY, self.layout.BODY_SIZE,
                    box_text_width, self.layout.BODY_LEADING
                )
                box_height = text_height + 18  # v13.3: Reduced from 22
                
                self.draw_card(
                    self.layout.MARGIN_LEFT, y, self.layout.TEXT_WIDTH, box_height,
                    accent_color=section.get('color', self.colors.GOLD)
                )
                
                self.draw_paragraph(
                    text, self.layout.MARGIN_LEFT + 14, y - 9,  # v13.3: Tighter internal offset
                    self.typography.BODY, self.layout.BODY_SIZE,
                    box_text_width, self.layout.BODY_LEADING,
                    color=self.colors.BODY
                )
                
                y -= box_height + self.layout.SPACE_LG
            
            elif section_type == 'divider':
                y = self.draw_section_divider(y)
                y -= self.layout.SPACE_SM
            
            elif section_type == 'bullet_list':
                bullet_indent = 26
                for item in section.get('items', []):
                    # Gold bullet
                    self.canvas.setFillColor(self.colors.GOLD)
                    self.canvas.circle(self.layout.MARGIN_LEFT + 5, y - 2, 4, fill=1, stroke=0)
                    
                    # Label
                    self.canvas.setFillColor(self.colors.BURGUNDY)
                    self.canvas.setFont(self.typography.HEADING, self.layout.H3_SIZE)
                    self.canvas.drawString(self.layout.MARGIN_LEFT + bullet_indent, y, item.get('label', ''))
                    
                    y -= self.layout.SPACE_SM + 2
                    
                    # Text
                    y = self.draw_paragraph(
                        item.get('text', ''),
                        self.layout.MARGIN_LEFT + bullet_indent, y,
                        self.typography.BODY, self.layout.BODY_SIZE,
                        self.layout.TEXT_WIDTH - bullet_indent, self.layout.BODY_LEADING,
                        color=self.colors.BODY
                    )
                    y -= self.layout.SPACE_MD
            
            elif section_type == 'quote':
                quote_x = self.layout.MARGIN_LEFT + 0.25 * inch
                quote_lines = section.get('lines', [])
                num_lines = len(quote_lines)
                # v13.3: Dynamic height with attribution inside box
                quote_bg_height = 60 + (num_lines * 18)
                
                # Background box
                self.canvas.setFillColor(self.colors.CARD)
                self.canvas.roundRect(
                    self.layout.MARGIN_LEFT, y - quote_bg_height + 10,
                    self.layout.TEXT_WIDTH, quote_bg_height, 6, fill=1, stroke=0
                )
                
                # Gold accent bar
                self.canvas.setFillColor(self.colors.GOLD)
                self.canvas.roundRect(
                    quote_x - 8, y - quote_bg_height + 18,
                    4, quote_bg_height - 16, 2, fill=1, stroke=0
                )
                
                # Opening quotation mark
                self.canvas.setFillColor(self.colors.GOLD)
                self.canvas.setFont(self.typography.HEADING, 72)
                self.canvas.drawString(quote_x + 5, y - 8, "\u201C")
                
                # Quote text
                self.canvas.setFillColor(self.colors.HEADING)
                self.canvas.setFont(self.typography.BODY_ITALIC, 14)
                
                line_y = y - 46
                for line in quote_lines:
                    self.canvas.drawString(quote_x + 20, line_y, line)
                    line_y -= 18
                
                # v13.3: Attribution positioned inside box, right-aligned
                self.canvas.setFillColor(self.colors.MUTED)
                self.canvas.setFont(self.typography.HEADING_REGULAR, 9)
                attribution = section.get('attribution', 'Insight Atlas')
                attr_text = f"— {attribution}"
                attr_width = self.canvas.stringWidth(attr_text, self.typography.HEADING_REGULAR, 9)
                self.canvas.drawString(
                    self.layout.MARGIN_LEFT + self.layout.TEXT_WIDTH - attr_width - 16,
                    y - quote_bg_height + 22,
                    attr_text
                )
                
                y -= quote_bg_height + self.layout.SPACE_MD
            
            # Check if we need a new page
            if y < self.layout.CONTENT_BOTTOM:
                self.draw_footer(page_num)
                self.canvas.showPage()
                self.current_page += 1
                page_num += 1
                
                self.canvas.setFillColor(self.colors.BG)
                self.canvas.rect(0, 0, self.layout.PAGE_WIDTH, self.layout.PAGE_HEIGHT, fill=1, stroke=0)
                self.draw_header()
                y = self.layout.CONTENT_TOP
        
        self.draw_footer(page_num)
        self.canvas.showPage()
        self.current_page += 1
        
        return page_num
    
    # ─────────────────────────────────────────────────────────────
    # MAIN GENERATION METHOD
    # ─────────────────────────────────────────────────────────────
    
    def generate(self, output_path: str, book_title: str, book_author: str,
                 analysis_data: Dict[str, Any], logo_path: Optional[str] = None):
        """
        Generate a complete PDF analysis document.
        
        Args:
            output_path: Path for the output PDF file
            book_title: Title of the book being analyzed
            book_author: Author of the book
            analysis_data: Dictionary containing:
                - at_a_glance: Dict of summary items
                - toc: List of TOC items
                - pages: List of page content definitions
            logo_path: Optional path to logo image
        """
        self.canvas = canvas.Canvas(output_path, pagesize=letter)
        self.current_page = 0
        
        # Set document metadata
        self.canvas.setTitle(f"{book_title} - Insight Atlas Analysis")
        self.canvas.setAuthor("Insight Atlas")
        self.canvas.setSubject(f"Analysis of {book_title} by {book_author}")
        self.canvas.setCreator("Insight Atlas Premium Document System v1.1.0")
        
        # Build cover page
        self.build_cover_page(
            book_title, book_author,
            analysis_data.get('at_a_glance', {}),
            logo_path
        )
        
        # Build TOC
        if 'toc' in analysis_data:
            self.build_toc_page(analysis_data['toc'])
        
        # Build content pages
        page_num = 3
        for page_content in analysis_data.get('pages', []):
            page_num = self.build_content_page(page_content, page_num)
        
        self.canvas.save()
        print(f"✓ PDF generated: {output_path}")


# ═══════════════════════════════════════════════════════════════
# CONVENIENCE FUNCTION
# ═══════════════════════════════════════════════════════════════

def create_analysis_pdf(output_path: str, book_title: str, book_author: str,
                        analysis_data: Dict[str, Any], logo_path: Optional[str] = None):
    """
    Convenience function to generate a PDF.
    
    This is a simple wrapper around the InsightAtlasPDF class.
    """
    pdf = InsightAtlasPDF()
    pdf.generate(output_path, book_title, book_author, analysis_data, logo_path)


# ═══════════════════════════════════════════════════════════════
# EXAMPLE USAGE
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Example: Generate a sample PDF
    sample_data = {
        'at_a_glance': {
            'Core Thesis': 'Intelligence extends beyond the brain',
            'Framework': '4E Cognition (Embodied, Embedded, Enacted, Extended)',
            'Applications': 'Workspace design, education, leadership'
        },
        'toc': [
            {'title': 'Executive Summary', 'page': '3', 'is_sub': False},
            {'title': 'Central Thesis', 'page': '3', 'is_sub': False},
            {'title': 'Key Takeaways', 'page': '4', 'is_sub': False},
        ],
        'pages': [
            [
                {'type': 'h2', 'text': 'Executive Summary', 'icon': '☉', 'color': InsightAtlasColors.GOLD},
                {'type': 'paragraph', 'text': 'This is a sample executive summary paragraph.'},
                {'type': 'divider'},
                {'type': 'h3', 'text': 'Central Thesis'},
                {'type': 'card', 'text': 'This is the central thesis in a highlighted card.'},
            ],
            [
                {'type': 'h2', 'text': 'Key Takeaways', 'icon': '★', 'color': InsightAtlasColors.GOLD},
                {'type': 'paragraph', 'text': 'These are the key takeaways from the analysis.'},
                {'type': 'quote', 'lines': ['Where the weight of understanding', 'becomes the clarity to act.'], 'attribution': 'Insight Atlas'},
            ]
        ]
    }
    
    pdf = InsightAtlasPDF()
    pdf.generate(
        output_path="sample_analysis.pdf",
        book_title="Sample Book",
        book_author="Sample Author",
        analysis_data=sample_data
    )
