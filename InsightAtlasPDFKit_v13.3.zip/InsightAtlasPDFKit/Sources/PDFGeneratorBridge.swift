//
//  PDFGeneratorBridge.swift
//  Insight Atlas
//
//  Bridge to call Python PDF generator from Swift.
//  Requires Python 3 with reportlab installed.
//

import Foundation

/// Bridge class to generate PDFs using the Python backend
class PDFGeneratorBridge {
    
    // MARK: - Configuration
    
    /// Path to Python executable (adjust if using virtualenv)
    private let pythonPath: String
    
    /// Path to the PDF generator script
    private let scriptPath: String
    
    /// Path to the logo asset
    private let logoPath: String?
    
    // MARK: - Initialization
    
    init(pythonPath: String = "/usr/bin/python3",
         scriptPath: String? = nil,
         logoPath: String? = nil) {
        
        self.pythonPath = pythonPath
        
        // Default to bundled script in Resources
        if let path = scriptPath {
            self.scriptPath = path
        } else {
            self.scriptPath = Bundle.main.path(forResource: "insight_atlas_pdf", ofType: "py") ?? ""
        }
        
        // Default to bundled logo
        if let path = logoPath {
            self.logoPath = path
        } else {
            self.logoPath = Bundle.main.path(forResource: "Logo", ofType: "png")
        }
    }
    
    // MARK: - Data Structures
    
    struct AnalysisData: Codable {
        var atAGlance: [String: String]
        var toc: [TOCItem]
        var pages: [[SectionData]]
        
        enum CodingKeys: String, CodingKey {
            case atAGlance = "at_a_glance"
            case toc
            case pages
        }
    }
    
    struct TOCItem: Codable {
        var title: String
        var page: String
        var isSub: Bool
        
        enum CodingKeys: String, CodingKey {
            case title
            case page
            case isSub = "is_sub"
        }
    }
    
    struct SectionData: Codable {
        var type: String
        var text: String?
        var icon: String?
        var color: String?
        var lines: [String]?
        var attribution: String?
        var items: [BulletItem]?
    }
    
    struct BulletItem: Codable {
        var label: String
        var text: String
    }
    
    // MARK: - Generation Methods
    
    /// Generate a PDF analysis document
    /// - Parameters:
    ///   - outputPath: Path where the PDF will be saved
    ///   - bookTitle: Title of the book
    ///   - bookAuthor: Author of the book
    ///   - analysisData: Structured analysis data
    ///   - completion: Callback with result
    func generatePDF(
        outputPath: String,
        bookTitle: String,
        bookAuthor: String,
        analysisData: AnalysisData,
        completion: @escaping (Result<URL, Error>) -> Void
    ) {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            
            do {
                // Write analysis data to temp JSON file
                let encoder = JSONEncoder()
                encoder.outputFormatting = .prettyPrinted
                let jsonData = try encoder.encode(analysisData)
                
                let tempDir = FileManager.default.temporaryDirectory
                let jsonPath = tempDir.appendingPathComponent("analysis_data.json")
                try jsonData.write(to: jsonPath)
                
                // Build command
                let process = Process()
                process.executableURL = URL(fileURLWithPath: self.pythonPath)
                
                var arguments = [
                    self.scriptPath,
                    "--output", outputPath,
                    "--title", bookTitle,
                    "--author", bookAuthor,
                    "--data", jsonPath.path
                ]
                
                if let logo = self.logoPath {
                    arguments.append(contentsOf: ["--logo", logo])
                }
                
                process.arguments = arguments
                
                let pipe = Pipe()
                process.standardOutput = pipe
                process.standardError = pipe
                
                try process.run()
                process.waitUntilExit()
                
                // Clean up temp file
                try? FileManager.default.removeItem(at: jsonPath)
                
                if process.terminationStatus == 0 {
                    DispatchQueue.main.async {
                        completion(.success(URL(fileURLWithPath: outputPath)))
                    }
                } else {
                    let data = pipe.fileHandleForReading.readDataToEndOfFile()
                    let output = String(data: data, encoding: .utf8) ?? "Unknown error"
                    DispatchQueue.main.async {
                        completion(.failure(PDFGenerationError.processFailed(output)))
                    }
                }
                
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    /// Generate PDF synchronously (for command-line tools)
    func generatePDFSync(
        outputPath: String,
        bookTitle: String,
        bookAuthor: String,
        analysisData: AnalysisData
    ) throws -> URL {
        
        var result: Result<URL, Error>?
        let semaphore = DispatchSemaphore(value: 0)
        
        generatePDF(
            outputPath: outputPath,
            bookTitle: bookTitle,
            bookAuthor: bookAuthor,
            analysisData: analysisData
        ) { res in
            result = res
            semaphore.signal()
        }
        
        semaphore.wait()
        
        switch result {
        case .success(let url):
            return url
        case .failure(let error):
            throw error
        case .none:
            throw PDFGenerationError.unknown
        }
    }
    
    // MARK: - Errors
    
    enum PDFGenerationError: Error, LocalizedError {
        case processFailed(String)
        case unknown
        
        var errorDescription: String? {
            switch self {
            case .processFailed(let output):
                return "PDF generation failed: \(output)"
            case .unknown:
                return "Unknown PDF generation error"
            }
        }
    }
}

// MARK: - Convenience Extension

extension PDFGeneratorBridge {
    
    /// Create analysis data from a simple dictionary structure
    static func createAnalysisData(
        atAGlance: [String: String],
        executiveSummary: String,
        centralThesis: String,
        sections: [(title: String, content: String, icon: String, isBurgundy: Bool)],
        applications: [(label: String, text: String)],
        limitations: String,
        keyTakeaways: String
    ) -> AnalysisData {
        
        // Build TOC
        var tocItems: [TOCItem] = [
            TOCItem(title: "Executive Summary", page: "3", isSub: false),
            TOCItem(title: "Central Thesis", page: "3", isSub: false),
        ]
        
        var pageNum = 3
        for section in sections {
            tocItems.append(TOCItem(title: section.title, page: "\(pageNum)", isSub: false))
        }
        
        tocItems.append(TOCItem(title: "Practical Applications", page: "\(pageNum + 1)", isSub: false))
        tocItems.append(TOCItem(title: "Limitations & Considerations", page: "\(pageNum + 2)", isSub: false))
        tocItems.append(TOCItem(title: "Key Takeaways", page: "\(pageNum + 2)", isSub: false))
        
        // Build pages
        var pages: [[SectionData]] = []
        
        // Page 1: Executive Summary + Central Thesis
        var page1: [SectionData] = [
            SectionData(type: "h2", text: "Executive Summary", icon: "☉", color: "#CBA135"),
            SectionData(type: "paragraph", text: executiveSummary),
            SectionData(type: "divider"),
            SectionData(type: "h3", text: "Central Thesis", color: "#582534"),
            SectionData(type: "card", text: centralThesis, color: "#CBA135"),
        ]
        
        // Add first section if exists
        if let first = sections.first {
            page1.append(SectionData(
                type: "h2", text: first.title, icon: first.icon,
                color: first.isBurgundy ? "#582534" : "#CBA135"
            ))
            page1.append(SectionData(type: "paragraph", text: first.content))
        }
        pages.append(page1)
        
        // Additional sections
        for section in sections.dropFirst() {
            pages.append([
                SectionData(
                    type: "h2", text: section.title, icon: section.icon,
                    color: section.isBurgundy ? "#582534" : "#CBA135"
                ),
                SectionData(type: "paragraph", text: section.content),
            ])
        }
        
        // Applications page
        let bulletItems = applications.map { BulletItem(label: $0.label, text: $0.text) }
        pages.append([
            SectionData(type: "h2", text: "Practical Applications", icon: "✦", color: "#CBA135"),
            SectionData(type: "bullet_list", items: bulletItems),
        ])
        
        // Limitations + Takeaways + Quote
        pages.append([
            SectionData(type: "h2", text: "Limitations & Considerations", icon: "◇", color: "#E76F51"),
            SectionData(type: "card", text: limitations, color: "#E76F51"),
            SectionData(type: "divider"),
            SectionData(type: "h2", text: "Key Takeaways", icon: "★", color: "#CBA135"),
            SectionData(type: "paragraph", text: keyTakeaways),
            SectionData(
                type: "quote",
                lines: ["Where the weight of understanding", "becomes the clarity to act."],
                attribution: "Insight Atlas"
            ),
        ])
        
        return AnalysisData(atAGlance: atAGlance, toc: tocItems, pages: pages)
    }
}
