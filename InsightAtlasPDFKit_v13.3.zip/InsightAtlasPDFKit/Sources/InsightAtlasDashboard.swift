//
//  InsightAtlasDashboard.swift
//  Insight Atlas
//
//  Main dashboard view with brand-consistent styling.
//  v13.3 Enhanced with hover states, animations, and PDF integration.
//

import SwiftUI

// MARK: - Main Dashboard View

struct InsightAtlasDashboard: View {
    @StateObject private var viewModel = DashboardViewModel()
    @State private var selectedAnalysis: BookAnalysis?
    @State private var showingNewAnalysis = false
    @State private var showingSettings = false
    @State private var showingExportProgress = false
    @State private var exportProgress: Double = 0
    
    var body: some View {
        NavigationSplitView {
            SidebarView(
                selectedSection: $viewModel.selectedSection,
                recentAnalyses: viewModel.recentAnalyses
            )
            .frame(minWidth: 220)
        } detail: {
            ZStack {
                InsightAtlasColors.background
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: InsightAtlasSpacing.xl) {
                        DashboardHeader(
                            showingNewAnalysis: $showingNewAnalysis,
                            showingSettings: $showingSettings
                        )
                        
                        StatsOverview(stats: viewModel.stats)
                        
                        RecentAnalysesSection(
                            analyses: viewModel.recentAnalyses,
                            onSelect: { selectedAnalysis = $0 },
                            onExport: { analysis in
                                exportAnalysis(analysis)
                            }
                        )
                        
                        QuickActionsSection()
                        
                        Spacer(minLength: 40)
                    }
                    .padding(.horizontal, 32)
                    .padding(.top, 24)
                }
                
                // Export progress overlay
                if showingExportProgress {
                    ExportProgressOverlay(progress: exportProgress)
                }
            }
        }
        .sheet(isPresented: $showingNewAnalysis) {
            NewAnalysisView()
        }
        .sheet(item: $selectedAnalysis) { analysis in
            AnalysisDetailView(
                analysis: analysis,
                onExport: { exportAnalysis(analysis) }
            )
        }
        .sheet(isPresented: $showingSettings) {
            SettingsView()
        }
    }
    
    private func exportAnalysis(_ analysis: BookAnalysis) {
        showingExportProgress = true
        exportProgress = 0
        
        // Simulate export progress
        Task {
            for i in 1...10 {
                try? await Task.sleep(nanoseconds: 100_000_000)
                await MainActor.run {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        exportProgress = Double(i) / 10.0
                    }
                }
            }
            
            // Call actual PDF generation here
            // PDFGeneratorBridge().generatePDF(...)
            
            await MainActor.run {
                withAnimation {
                    showingExportProgress = false
                }
            }
        }
    }
}

// MARK: - Export Progress Overlay

struct ExportProgressOverlay: View {
    let progress: Double
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.4)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                ZStack {
                    Circle()
                        .stroke(InsightAtlasColors.ruleLight, lineWidth: 4)
                        .frame(width: 60, height: 60)
                    
                    Circle()
                        .trim(from: 0, to: progress)
                        .stroke(InsightAtlasColors.gold, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                        .frame(width: 60, height: 60)
                        .rotationEffect(.degrees(-90))
                    
                    if progress >= 1.0 {
                        Image(systemName: "checkmark")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(InsightAtlasColors.gold)
                    } else {
                        Text("\(Int(progress * 100))%")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(InsightAtlasColors.heading)
                    }
                }
                
                Text(progress >= 1.0 ? "Export Complete" : "Generating PDF...")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(InsightAtlasColors.heading)
            }
            .padding(32)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(InsightAtlasColors.card)
                    .shadow(color: .black.opacity(0.15), radius: 20, y: 10)
            )
        }
    }
}

// MARK: - Sidebar

struct SidebarView: View {
    @Binding var selectedSection: DashboardSection
    let recentAnalyses: [BookAnalysis]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Logo area
            HStack(spacing: 10) {
                Image("Logo")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 32, height: 32)
                
                Text("Insight Atlas")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(InsightAtlasColors.heading)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 20)
            
            Divider()
                .background(InsightAtlasColors.ruleLight)
            
            // Navigation sections
            VStack(spacing: 4) {
                ForEach(DashboardSection.allCases, id: \.self) { section in
                    SidebarRow(
                        section: section,
                        isSelected: selectedSection == section
                    ) {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            selectedSection = section
                        }
                    }
                }
            }
            .padding(.top, 12)
            .padding(.horizontal, 8)
            
            Spacer()
            
            // Recent files
            VStack(alignment: .leading, spacing: 8) {
                Text("RECENT")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(InsightAtlasColors.muted)
                    .padding(.horizontal, 16)
                
                ForEach(recentAnalyses.prefix(5)) { analysis in
                    SidebarRecentItem(analysis: analysis)
                }
            }
            .padding(.bottom, 20)
        }
        .background(InsightAtlasColors.card)
    }
}

struct SidebarRow: View {
    let section: DashboardSection
    let isSelected: Bool
    let action: () -> Void
    
    @State private var isHovered = false
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Image(systemName: section.icon)
                    .font(.system(size: 14))
                    .foregroundColor(isSelected ? InsightAtlasColors.gold : InsightAtlasColors.muted)
                    .frame(width: 20)
                
                Text(section.title)
                    .font(.system(size: 13, weight: isSelected ? .semibold : .regular))
                    .foregroundColor(isSelected ? InsightAtlasColors.heading : InsightAtlasColors.body)
                
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 6)
                    .fill(isSelected ? InsightAtlasColors.gold.opacity(0.12) :
                            (isHovered ? InsightAtlasColors.ruleLight.opacity(0.5) : Color.clear))
            )
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            withAnimation(.easeInOut(duration: 0.15)) {
                isHovered = hovering
            }
        }
    }
}

struct SidebarRecentItem: View {
    let analysis: BookAnalysis
    @State private var isHovered = false
    
    var body: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(analysis.category.color)
                .frame(width: 6, height: 6)
            
            Text(analysis.bookTitle)
                .font(.system(size: 12))
                .foregroundColor(InsightAtlasColors.body)
                .lineLimit(1)
            
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 4)
        .background(
            RoundedRectangle(cornerRadius: 4)
                .fill(isHovered ? InsightAtlasColors.ruleLight.opacity(0.3) : Color.clear)
        )
        .onHover { hovering in
            withAnimation(.easeInOut(duration: 0.15)) {
                isHovered = hovering
            }
        }
    }
}

// MARK: - Dashboard Header

struct DashboardHeader: View {
    @Binding var showingNewAnalysis: Bool
    @Binding var showingSettings: Bool
    
    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 8) {
                Text(greetingText)
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(InsightAtlasColors.heading)
                
                Text(InsightAtlasBrand.taglineShort)
                    .font(.system(size: 14, weight: .medium, design: .serif))
                    .italic()
                    .foregroundColor(InsightAtlasColors.muted)
            }
            
            Spacer()
            
            HStack(spacing: 12) {
                HeaderButton(icon: "gearshape", label: "Settings") {
                    showingSettings = true
                }
                
                HeaderButton(icon: "plus", label: "New Analysis", isPrimary: true) {
                    showingNewAnalysis = true
                }
            }
        }
    }
    
    private var greetingText: String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 5..<12: return "Good Morning"
        case 12..<17: return "Good Afternoon"
        default: return "Good Evening"
        }
    }
}

struct HeaderButton: View {
    let icon: String
    let label: String
    var isPrimary: Bool = false
    let action: () -> Void
    
    @State private var isHovered = false
    @State private var isPressed = false
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .semibold))
                Text(label)
                    .font(.system(size: 12, weight: .semibold))
            }
            .foregroundColor(isPrimary ? .white : InsightAtlasColors.heading)
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(isPrimary ?
                          (isPressed ? InsightAtlasColors.goldDark : InsightAtlasColors.gold) :
                            (isHovered ? InsightAtlasColors.ruleLight : InsightAtlasColors.card))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(isPrimary ? Color.clear : InsightAtlasColors.rule, lineWidth: 1)
            )
            .scaleEffect(isPressed ? 0.97 : 1.0)
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            withAnimation(.easeInOut(duration: 0.15)) {
                isHovered = hovering
            }
        }
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    withAnimation(.easeInOut(duration: 0.1)) {
                        isPressed = true
                    }
                }
                .onEnded { _ in
                    withAnimation(.easeInOut(duration: 0.1)) {
                        isPressed = false
                    }
                }
        )
    }
}

// MARK: - Stats Overview

struct StatsOverview: View {
    let stats: DashboardStats
    
    var body: some View {
        HStack(spacing: 16) {
            StatCard(
                title: "Total Analyses",
                value: "\(stats.totalAnalyses)",
                icon: "doc.text.fill",
                color: InsightAtlasColors.gold
            )
            
            StatCard(
                title: "This Month",
                value: "\(stats.thisMonth)",
                icon: "calendar",
                color: InsightAtlasColors.burgundy
            )
            
            StatCard(
                title: "Favorites",
                value: "\(stats.favorites)",
                icon: "star.fill",
                color: InsightAtlasColors.coral
            )
            
            StatCard(
                title: "Exports",
                value: "\(stats.exports)",
                icon: "arrow.down.doc.fill",
                color: InsightAtlasColors.gold
            )
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    @State private var isHovered = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: icon)
                    .font(.system(size: 16))
                    .foregroundColor(color)
                
                Spacer()
            }
            
            Text(value)
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(InsightAtlasColors.heading)
            
            Text(title)
                .font(.system(size: 12))
                .foregroundColor(InsightAtlasColors.muted)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(InsightAtlasColors.card)
                .shadow(color: isHovered ? color.opacity(0.15) : .clear, radius: 8, y: 4)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(isHovered ? color.opacity(0.3) : InsightAtlasColors.ruleLight, lineWidth: 1)
        )
        .scaleEffect(isHovered ? 1.02 : 1.0)
        .onHover { hovering in
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                isHovered = hovering
            }
        }
    }
}

// MARK: - Recent Analyses Section

struct RecentAnalysesSection: View {
    let analyses: [BookAnalysis]
    let onSelect: (BookAnalysis) -> Void
    let onExport: (BookAnalysis) -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Recent Analyses")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(InsightAtlasColors.heading)
                
                Spacer()
                
                Button("View All") {
                    // Navigate to all analyses
                }
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(InsightAtlasColors.gold)
            }
            
            LazyVGrid(columns: [
                GridItem(.flexible(), spacing: 16),
                GridItem(.flexible(), spacing: 16),
                GridItem(.flexible(), spacing: 16)
            ], spacing: 16) {
                ForEach(analyses) { analysis in
                    AnalysisCard(
                        analysis: analysis,
                        onSelect: { onSelect(analysis) },
                        onExport: { onExport(analysis) }
                    )
                }
            }
        }
    }
}

struct AnalysisCard: View {
    let analysis: BookAnalysis
    let onSelect: () -> Void
    let onExport: () -> Void
    
    @State private var isHovered = false
    @State private var showActions = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Category badge
            HStack {
                CategoryBadge(category: analysis.category)
                
                Spacer()
                
                if analysis.isFavorite {
                    Image(systemName: "star.fill")
                        .font(.system(size: 12))
                        .foregroundColor(InsightAtlasColors.gold)
                }
                
                // Hover actions
                if isHovered {
                    HStack(spacing: 4) {
                        CardActionButton(icon: "arrow.down.doc") {
                            onExport()
                        }
                    }
                    .transition(.opacity.combined(with: .scale(scale: 0.9)))
                }
            }
            
            // Title and author
            VStack(alignment: .leading, spacing: 4) {
                Text(analysis.bookTitle)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(InsightAtlasColors.heading)
                    .lineLimit(2)
                
                Text("by \(analysis.bookAuthor)")
                    .font(.system(size: 12, design: .serif))
                    .italic()
                    .foregroundColor(InsightAtlasColors.muted)
            }
            
            Spacer()
            
            // Thesis preview
            if let thesis = analysis.coreThesis {
                Text(thesis)
                    .font(.system(size: 11, design: .serif))
                    .foregroundColor(InsightAtlasColors.body)
                    .lineLimit(3)
            }
            
            // Footer
            HStack {
                Text(analysis.dateCreated.formatted(date: .abbreviated, time: .omitted))
                    .font(.system(size: 10))
                    .foregroundColor(InsightAtlasColors.muted)
                
                Spacer()
                
                if analysis.isComplete {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 12))
                        .foregroundColor(InsightAtlasColors.gold)
                } else {
                    Text("In Progress")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(InsightAtlasColors.coral)
                }
            }
        }
        .padding(16)
        .frame(height: 200)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(InsightAtlasColors.card)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(isHovered ? InsightAtlasColors.gold.opacity(0.4) : InsightAtlasColors.ruleLight, lineWidth: 1)
        )
        .shadow(color: isHovered ? InsightAtlasColors.gold.opacity(0.1) : .clear, radius: 8, y: 4)
        .scaleEffect(isHovered ? 1.02 : 1.0)
        .onTapGesture {
            onSelect()
        }
        .onHover { hovering in
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                isHovered = hovering
            }
        }
    }
}

struct CardActionButton: View {
    let icon: String
    let action: () -> Void
    
    @State private var isHovered = false
    
    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(isHovered ? InsightAtlasColors.gold : InsightAtlasColors.muted)
                .padding(6)
                .background(
                    Circle()
                        .fill(isHovered ? InsightAtlasColors.gold.opacity(0.15) : InsightAtlasColors.ruleLight)
                )
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            withAnimation(.easeInOut(duration: 0.15)) {
                isHovered = hovering
            }
        }
    }
}

struct CategoryBadge: View {
    let category: BookCategory
    
    var body: some View {
        Text(category.rawValue)
            .font(.system(size: 9, weight: .bold))
            .foregroundColor(category.color)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                Capsule()
                    .fill(category.color.opacity(0.12))
            )
    }
}

// MARK: - Quick Actions Section

struct QuickActionsSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Quick Actions")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(InsightAtlasColors.heading)
            
            HStack(spacing: 16) {
                QuickActionCard(
                    icon: "doc.badge.plus",
                    title: "New Analysis",
                    description: "Start analyzing a new book",
                    color: InsightAtlasColors.gold
                ) {
                    // Action
                }
                
                QuickActionCard(
                    icon: "square.and.arrow.up",
                    title: "Batch Export",
                    description: "Export multiple analyses as PDFs",
                    color: InsightAtlasColors.burgundy
                ) {
                    // Action
                }
                
                QuickActionCard(
                    icon: "folder.badge.gearshape",
                    title: "Templates",
                    description: "Manage analysis templates",
                    color: InsightAtlasColors.coral
                ) {
                    // Action
                }
            }
        }
    }
}

struct QuickActionCard: View {
    let icon: String
    let title: String
    let description: String
    let color: Color
    let action: () -> Void
    
    @State private var isHovered = false
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(color.opacity(0.12))
                        .frame(width: 44, height: 44)
                    
                    Image(systemName: icon)
                        .font(.system(size: 18))
                        .foregroundColor(color)
                }
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(InsightAtlasColors.heading)
                    
                    Text(description)
                        .font(.system(size: 11))
                        .foregroundColor(InsightAtlasColors.muted)
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(InsightAtlasColors.muted)
                    .opacity(isHovered ? 1 : 0.5)
            }
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(InsightAtlasColors.card)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(isHovered ? color.opacity(0.3) : InsightAtlasColors.ruleLight, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            withAnimation(.easeInOut(duration: 0.15)) {
                isHovered = hovering
            }
        }
    }
}

// MARK: - Settings View

struct SettingsView: View {
    @Environment(\.dismiss) var dismiss
    @State private var pythonPath = "/usr/bin/python3"
    @State private var defaultExportPath = "~/Desktop"
    @State private var autoOpenPDF = true
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Settings")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(InsightAtlasColors.heading)
                
                Spacer()
                
                Button(action: { dismiss() }) {
                    Image(systemName: "xmark")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(InsightAtlasColors.muted)
                        .padding(8)
                        .background(Circle().fill(InsightAtlasColors.ruleLight))
                }
                .buttonStyle(.plain)
            }
            .padding(24)
            
            Divider()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    // PDF Generation section
                    SettingsSection(title: "PDF Generation") {
                        SettingsTextField(
                            label: "Python Path",
                            placeholder: "/usr/bin/python3",
                            text: $pythonPath
                        )
                        
                        SettingsTextField(
                            label: "Default Export Location",
                            placeholder: "~/Desktop",
                            text: $defaultExportPath
                        )
                        
                        SettingsToggle(
                            label: "Open PDF after export",
                            isOn: $autoOpenPDF
                        )
                    }
                    
                    // About section
                    SettingsSection(title: "About") {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Insight Atlas")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(InsightAtlasColors.heading)
                                
                                Text("v1.1.0 (v13.3 Minimalist Premium)")
                                    .font(.system(size: 12))
                                    .foregroundColor(InsightAtlasColors.muted)
                            }
                            
                            Spacer()
                            
                            Image("Logo")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 40, height: 40)
                        }
                    }
                }
                .padding(24)
            }
        }
        .frame(width: 480, height: 400)
        .background(InsightAtlasColors.background)
    }
}

struct SettingsSection<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title.uppercased())
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(InsightAtlasColors.muted)
            
            VStack(spacing: 12) {
                content
            }
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(InsightAtlasColors.card)
            )
        }
    }
}

struct SettingsTextField: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(InsightAtlasColors.body)
            
            TextField(placeholder, text: $text)
                .textFieldStyle(.plain)
                .font(.system(size: 13))
                .padding(10)
                .background(
                    RoundedRectangle(cornerRadius: 6)
                        .fill(InsightAtlasColors.background)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(InsightAtlasColors.rule, lineWidth: 1)
                )
        }
    }
}

struct SettingsToggle: View {
    let label: String
    @Binding var isOn: Bool
    
    var body: some View {
        Toggle(isOn: $isOn) {
            Text(label)
                .font(.system(size: 13))
                .foregroundColor(InsightAtlasColors.body)
        }
        .toggleStyle(.switch)
        .tint(InsightAtlasColors.gold)
    }
}

// MARK: - New Analysis View

struct NewAnalysisView: View {
    @Environment(\.dismiss) var dismiss
    @State private var bookTitle = ""
    @State private var bookAuthor = ""
    @State private var selectedCategory: BookCategory = .philosophy
    @State private var contentText = ""
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("New Analysis")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(InsightAtlasColors.heading)
                
                Spacer()
                
                Button(action: { dismiss() }) {
                    Image(systemName: "xmark")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(InsightAtlasColors.muted)
                        .padding(8)
                        .background(Circle().fill(InsightAtlasColors.ruleLight))
                }
                .buttonStyle(.plain)
            }
            .padding(24)
            
            Divider()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // Book details
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Book Details")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(InsightAtlasColors.muted)
                        
                        TextField("Book Title", text: $bookTitle)
                            .textFieldStyle(.plain)
                            .font(.system(size: 14))
                            .padding(12)
                            .background(RoundedRectangle(cornerRadius: 8).fill(InsightAtlasColors.card))
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(InsightAtlasColors.rule))
                        
                        TextField("Author", text: $bookAuthor)
                            .textFieldStyle(.plain)
                            .font(.system(size: 14))
                            .padding(12)
                            .background(RoundedRectangle(cornerRadius: 8).fill(InsightAtlasColors.card))
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(InsightAtlasColors.rule))
                        
                        // Category picker
                        HStack {
                            Text("Category")
                                .font(.system(size: 13))
                                .foregroundColor(InsightAtlasColors.body)
                            
                            Spacer()
                            
                            Picker("", selection: $selectedCategory) {
                                ForEach(BookCategory.allCases, id: \.self) { category in
                                    Text(category.rawValue).tag(category)
                                }
                            }
                            .pickerStyle(.menu)
                        }
                    }
                    
                    // Content input
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Content")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(InsightAtlasColors.muted)
                        
                        TextEditor(text: $contentText)
                            .font(.system(size: 13, design: .serif))
                            .frame(minHeight: 150)
                            .padding(12)
                            .background(RoundedRectangle(cornerRadius: 8).fill(InsightAtlasColors.card))
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(InsightAtlasColors.rule))
                    }
                }
                .padding(24)
            }
            
            Divider()
            
            // Footer
            HStack {
                Button("Cancel") {
                    dismiss()
                }
                .buttonStyle(.plain)
                .foregroundColor(InsightAtlasColors.muted)
                
                Spacer()
                
                Button(action: {
                    // Start analysis
                    dismiss()
                }) {
                    Text("Begin Analysis")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(RoundedRectangle(cornerRadius: 8).fill(InsightAtlasColors.gold))
                }
                .buttonStyle(.plain)
            }
            .padding(24)
        }
        .frame(width: 520, height: 540)
        .background(InsightAtlasColors.background)
    }
}

// MARK: - Analysis Detail View

struct AnalysisDetailView: View {
    let analysis: BookAnalysis
    let onExport: () -> Void
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(analysis.bookTitle)
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(InsightAtlasColors.heading)
                    
                    Text("by \(analysis.bookAuthor)")
                        .font(.system(size: 14, design: .serif))
                        .italic()
                        .foregroundColor(InsightAtlasColors.muted)
                }
                
                Spacer()
                
                HStack(spacing: 8) {
                    Button(action: onExport) {
                        HStack(spacing: 4) {
                            Image(systemName: "arrow.down.doc")
                            Text("Export PDF")
                        }
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(RoundedRectangle(cornerRadius: 8).fill(InsightAtlasColors.gold))
                    }
                    .buttonStyle(.plain)
                    
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(InsightAtlasColors.muted)
                            .padding(8)
                            .background(Circle().fill(InsightAtlasColors.ruleLight))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(24)
            
            Divider()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    // Core Thesis
                    if let thesis = analysis.coreThesis {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("CORE THESIS")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(InsightAtlasColors.burgundy)
                            
                            Text(thesis)
                                .font(.system(size: 14, design: .serif))
                                .foregroundColor(InsightAtlasColors.body)
                                .padding(16)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(
                                    RoundedRectangle(cornerRadius: 8)
                                        .fill(InsightAtlasColors.card)
                                )
                                .overlay(
                                    HStack {
                                        Rectangle()
                                            .fill(InsightAtlasColors.gold)
                                            .frame(width: 4)
                                        Spacer()
                                    }
                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                                )
                        }
                    }
                    
                    // Metadata
                    HStack(spacing: 24) {
                        MetadataItem(label: "Category", value: analysis.category.rawValue)
                        MetadataItem(label: "Created", value: analysis.dateCreated.formatted())
                        MetadataItem(label: "Status", value: analysis.isComplete ? "Complete" : "In Progress")
                    }
                }
                .padding(24)
            }
        }
        .frame(width: 640, height: 480)
        .background(InsightAtlasColors.background)
    }
}

struct MetadataItem: View {
    let label: String
    let value: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label.uppercased())
                .font(.system(size: 9, weight: .bold))
                .foregroundColor(InsightAtlasColors.muted)
            
            Text(value)
                .font(.system(size: 13))
                .foregroundColor(InsightAtlasColors.body)
        }
    }
}

// MARK: - Data Models

enum DashboardSection: String, CaseIterable {
    case dashboard = "Dashboard"
    case analyses = "Analyses"
    case favorites = "Favorites"
    case templates = "Templates"
    case exports = "Exports"
    
    var title: String { rawValue }
    
    var icon: String {
        switch self {
        case .dashboard: return "square.grid.2x2"
        case .analyses: return "doc.text"
        case .favorites: return "star"
        case .templates: return "doc.badge.gearshape"
        case .exports: return "arrow.down.doc"
        }
    }
}

enum BookCategory: String, CaseIterable {
    case philosophy = "Philosophy"
    case science = "Science"
    case business = "Business"
    case psychology = "Psychology"
    case history = "History"
    case technology = "Technology"
    
    var color: Color {
        switch self {
        case .philosophy: return InsightAtlasColors.burgundy
        case .science: return InsightAtlasColors.coral
        case .business: return InsightAtlasColors.gold
        case .psychology: return Color(hex: "#6B5B95")
        case .history: return Color(hex: "#88B04B")
        case .technology: return Color(hex: "#2980B9")
        }
    }
}

struct BookAnalysis: Identifiable {
    let id: UUID
    let bookTitle: String
    let bookAuthor: String
    let coreThesis: String?
    let dateCreated: Date
    let isComplete: Bool
    let isFavorite: Bool
    let category: BookCategory
}

struct DashboardStats {
    var totalAnalyses: Int
    var thisMonth: Int
    var favorites: Int
    var exports: Int
}

// MARK: - View Model

class DashboardViewModel: ObservableObject {
    @Published var selectedSection: DashboardSection = .dashboard
    @Published var recentAnalyses: [BookAnalysis] = []
    @Published var stats = DashboardStats(totalAnalyses: 0, thisMonth: 0, favorites: 0, exports: 0)
    
    init() {
        loadSampleData()
    }
    
    private func loadSampleData() {
        recentAnalyses = [
            BookAnalysis(
                id: UUID(),
                bookTitle: "The Extended Mind",
                bookAuthor: "Annie Murphy Paul",
                coreThesis: "Intelligence extends beyond the brain into the body, spaces, and relationships that surround us.",
                dateCreated: Date().addingTimeInterval(-86400),
                isComplete: true,
                isFavorite: true,
                category: .psychology
            ),
            BookAnalysis(
                id: UUID(),
                bookTitle: "Thinking in Systems",
                bookAuthor: "Donella Meadows",
                coreThesis: "Complex problems require understanding the interconnected systems that create them.",
                dateCreated: Date().addingTimeInterval(-86400 * 3),
                isComplete: true,
                isFavorite: false,
                category: .science
            ),
            BookAnalysis(
                id: UUID(),
                bookTitle: "The Innovator's Dilemma",
                bookAuthor: "Clayton Christensen",
                coreThesis: "Successful companies fail by doing everything right when facing disruptive innovation.",
                dateCreated: Date().addingTimeInterval(-86400 * 7),
                isComplete: false,
                isFavorite: false,
                category: .business
            ),
        ]
        
        stats = DashboardStats(
            totalAnalyses: 12,
            thisMonth: 3,
            favorites: 4,
            exports: 8
        )
    }
}

// MARK: - Preview

#Preview {
    InsightAtlasDashboard()
        .frame(width: 1200, height: 800)
}
