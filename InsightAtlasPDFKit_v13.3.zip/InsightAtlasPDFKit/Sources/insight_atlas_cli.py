#!/usr/bin/env python3
"""
Insight Atlas PDF Generator - CLI Interface

This script provides a command-line interface for generating
Insight Atlas branded PDF documents.

Usage:
    python insight_atlas_cli.py --output output.pdf --title "Book Title" --author "Author" --data analysis.json

Or with direct content:
    python insight_atlas_cli.py --output output.pdf --title "Book Title" --author "Author" \
        --thesis "Central thesis text" --summary "Executive summary text"
"""

import argparse
import json
import os
import sys

# Add the Sources directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from insight_atlas_pdf import InsightAtlasPDF, InsightAtlasColors


def main():
    parser = argparse.ArgumentParser(
        description='Generate Insight Atlas branded PDF analysis documents'
    )
    
    # Required arguments
    parser.add_argument('--output', '-o', required=True,
                        help='Output PDF file path')
    parser.add_argument('--title', '-t', required=True,
                        help='Book title')
    parser.add_argument('--author', '-a', required=True,
                        help='Book author')
    
    # Data source (either JSON file or direct content)
    parser.add_argument('--data', '-d',
                        help='Path to JSON file with analysis data')
    
    # Direct content options (alternative to --data)
    parser.add_argument('--summary',
                        help='Executive summary text')
    parser.add_argument('--thesis',
                        help='Central thesis text')
    parser.add_argument('--takeaways',
                        help='Key takeaways text')
    
    # Optional
    parser.add_argument('--logo', '-l',
                        help='Path to logo image')
    parser.add_argument('--core-thesis',
                        help='At a glance: Core thesis')
    parser.add_argument('--framework',
                        help='At a glance: Framework')
    parser.add_argument('--applications',
                        help='At a glance: Applications')
    
    args = parser.parse_args()
    
    # Load or build analysis data
    if args.data:
        with open(args.data, 'r') as f:
            analysis_data = json.load(f)
    else:
        # Build from direct arguments
        analysis_data = build_simple_analysis(args)
    
    # Find logo
    logo_path = args.logo
    if not logo_path:
        # Look for logo in standard locations
        possible_logos = [
            os.path.join(os.path.dirname(__file__), 'Assets', 'Logo.png'),
            os.path.join(os.path.dirname(__file__), '..', 'Assets', 'Logo.png'),
            '/usr/local/share/insight-atlas/Logo.png',
        ]
        for path in possible_logos:
            if os.path.exists(path):
                logo_path = path
                break
    
    # Generate PDF
    pdf = InsightAtlasPDF()
    pdf.generate(
        output_path=args.output,
        book_title=args.title,
        book_author=args.author,
        analysis_data=analysis_data,
        logo_path=logo_path
    )
    
    print(f"✓ PDF saved to: {args.output}")
    return 0


def build_simple_analysis(args):
    """Build analysis data from simple command-line arguments."""
    
    at_a_glance = {}
    if args.core_thesis:
        at_a_glance['Core Thesis'] = args.core_thesis
    if args.framework:
        at_a_glance['Framework'] = args.framework
    if args.applications:
        at_a_glance['Applications'] = args.applications
    
    # Default values if not provided
    if not at_a_glance:
        at_a_glance = {
            'Core Thesis': 'Analysis pending',
            'Framework': 'To be determined',
            'Applications': 'Various domains'
        }
    
    summary = args.summary or "Executive summary to be provided."
    thesis = args.thesis or "Central thesis to be provided."
    takeaways = args.takeaways or "Key takeaways to be provided."
    
    return {
        'at_a_glance': at_a_glance,
        'toc': [
            {'title': 'Executive Summary', 'page': '3', 'is_sub': False},
            {'title': 'Central Thesis', 'page': '3', 'is_sub': False},
            {'title': 'Key Takeaways', 'page': '3', 'is_sub': False},
        ],
        'pages': [
            [
                {'type': 'h2', 'text': 'Executive Summary', 'icon': '☉', 'color': '#CBA135'},
                {'type': 'paragraph', 'text': summary},
                {'type': 'divider'},
                {'type': 'h3', 'text': 'Central Thesis', 'color': '#582534'},
                {'type': 'card', 'text': thesis, 'color': '#CBA135'},
                {'type': 'divider'},
                {'type': 'h2', 'text': 'Key Takeaways', 'icon': '★', 'color': '#CBA135'},
                {'type': 'paragraph', 'text': takeaways},
                {
                    'type': 'quote',
                    'lines': ['Where the weight of understanding', 'becomes the clarity to act.'],
                    'attribution': 'Insight Atlas'
                },
            ]
        ]
    }


if __name__ == '__main__':
    sys.exit(main())
